<?php
/*Function of his file is very obvious.. */
require ("form.php");
?>
